<div class="page-footer">
				<div class="row">
					<div class="col-md-12">
						<span class="footer-text"><?= date('Y') ?> © SISAGU</span>
					</div>
				</div>
			</div>